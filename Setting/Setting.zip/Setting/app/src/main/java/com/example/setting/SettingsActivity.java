package com.example.setting;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;

public class SettingsActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        SharedPreferences PhoneNumber_prfrcs =
                PreferenceManager.getDefaultSharedPreferences(this /* Activity context */);
        String ph_num = PhoneNumber_prfrcs.getString("phone_number", "");
        String[] phone_number = ph_num.split("\n");
        SharedPreferences Message_Prfrcs =
                PreferenceManager.getDefaultSharedPreferences(this /* Activity context */);
        String message = Message_Prfrcs.getString("message", "");
        SharedPreferences Name_Prfrcs =
                PreferenceManager.getDefaultSharedPreferences(this /* Activity context */);
        String User_Name = Name_Prfrcs.getString("name", "");
        String[] message_text = message.split("\n");
        int message_len = message_text.length;
        message_text[message_len] = User_Name+"님의 핸드폰으로부터";
        
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
        }
    }
}